import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageBase64, mimeType } = await req.json();

    if (!imageBase64) {
      return new Response(JSON.stringify({ error: "No image provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const prompt = `You are a crowd density analysis AI. Analyze this image of a crowd/gathering and identify distinct zones with different crowd densities.

For each zone you identify, provide:
- name: A descriptive name for the zone based on what you see (e.g., "Main Stage Area", "Left Corridor", "Entry Gate", "Food Stalls", "Open Ground", "Seated Area", etc.). Use names that describe what's actually visible in the image.
- x: horizontal position as a decimal 0-1 (0=left, 1=right) 
- y: vertical position as a decimal 0-1 (0=top, 1=bottom)
- radius: size of the zone as decimal 0.05-0.2
- density: crowd density percentage 0-100 based on how packed that area looks

Return ONLY a valid JSON array, no markdown, no explanation. Example:
[{"name":"Main Stage Area","x":0.5,"y":0.4,"radius":0.12,"density":85},{"name":"Open Ground","x":0.2,"y":0.7,"radius":0.1,"density":30}]

Identify 4-7 zones. Be accurate about WHERE in the image dense crowds appear. Higher density = more tightly packed people.`;

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: {
                    url: `data:${mimeType || "image/jpeg"};base64,${imageBase64}`,
                  },
                },
              ],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);

      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      throw new Error(`AI gateway returned ${response.status}`);
    }

    const result = await response.json();
    const content = result.choices?.[0]?.message?.content || "";

    // Extract JSON from response (handle markdown code blocks)
    let jsonStr = content.trim();
    if (jsonStr.startsWith("```")) {
      jsonStr = jsonStr.replace(/```json?\n?/g, "").replace(/```/g, "").trim();
    }

    const zones = JSON.parse(jsonStr);

    // Validate and add IDs
    const validatedZones = zones.map((z: any, i: number) => ({
      id: `zone-${i}`,
      name: String(z.name || `Zone ${i + 1}`),
      x: Math.max(0.05, Math.min(0.95, Number(z.x) || 0.5)),
      y: Math.max(0.05, Math.min(0.95, Number(z.y) || 0.5)),
      radius: Math.max(0.05, Math.min(0.2, Number(z.radius) || 0.1)),
      density: Math.max(0, Math.min(100, Math.round(Number(z.density) || 50))),
    }));

    return new Response(JSON.stringify({ zones: validatedZones }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-crowd error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Analysis failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

import { useState, useEffect } from "react";
import DashboardHeader from "../components/DashboardHeader";
import { AlertTriangle, Bell, Clock, Radio, Shield } from "lucide-react";
import { type DensityZone } from "../components/HeatmapVisualization";

interface Alert {
  id: number;
  timestamp: string;
  zones: DensityZone[];
  status: string;
}

const PolicePortal = () => {
  const [latestZones, setLatestZones] = useState<DensityZone[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [lastUpdate, setLastUpdate] = useState<string | null>(null);

  useEffect(() => {
    // Load initial data
    try {
      const latest = localStorage.getItem("crowdguard_latest");
      if (latest) {
        const data = JSON.parse(latest);
        setLatestZones(data.zones || []);
        setLastUpdate(new Date(data.timestamp).toLocaleTimeString());
      }
      const alertData = localStorage.getItem("crowdguard_alerts");
      if (alertData) setAlerts(JSON.parse(alertData));
    } catch {}

    // Listen for live updates
    const handler = (e: StorageEvent) => {
      if (e.key === "crowdguard_latest") {
        try {
          const data = JSON.parse(e.newValue || "{}");
          setLatestZones(data.zones || []);
          setLastUpdate(new Date(data.timestamp).toLocaleTimeString());
        } catch {}
      }
      if (e.key === "crowdguard_alerts") {
        try {
          setAlerts(JSON.parse(e.newValue || "[]"));
        } catch {}
      }
    };

    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  const dangerZones = latestZones.filter((z) => z.density >= 80);
  const warningZones = latestZones.filter((z) => z.density >= 50 && z.density < 80);

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <main className="container mx-auto px-4 py-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Shield className="h-6 w-6 text-primary" />
              Police Response Portal
            </h2>
            <p className="text-sm text-muted-foreground">Live crowd density alerts and zone monitoring</p>
          </div>
          <div className="flex items-center gap-2 rounded-md bg-secondary px-3 py-2">
            <Radio className="h-3 w-3 animate-pulse text-safe" />
            <span className="font-mono text-xs text-safe">LIVE FEED</span>
            {lastUpdate && (
              <span className="font-mono text-xs text-muted-foreground">• Updated {lastUpdate}</span>
            )}
          </div>
        </div>

        {/* Critical Alerts Banner */}
        {dangerZones.length > 0 && (
          <div className="mb-6 rounded-lg border border-primary/50 bg-primary/10 p-4 glow-danger pulse-danger">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-6 w-6 text-primary" />
              <div>
                <p className="font-mono text-sm font-bold text-primary">
                  ⚠ {dangerZones.length} CRITICAL ZONE{dangerZones.length > 1 ? "S" : ""} — ACTION REQUIRED
                </p>
                <p className="font-mono text-xs text-foreground">
                  {dangerZones.map((z) => `${z.name}: ${z.density}% capacity`).join(" • ")}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Live Zone Status */}
          <div className="rounded-lg border border-border bg-card p-5">
            <h3 className="mb-4 flex items-center gap-2 font-mono text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              <Radio className="h-4 w-4" />
              Live Zone Status
            </h3>
            {latestZones.length === 0 ? (
              <p className="text-sm text-muted-foreground">Awaiting density data from control center...</p>
            ) : (
              <div className="space-y-3">
                {latestZones
                  .sort((a, b) => b.density - a.density)
                  .map((zone) => (
                    <div
                      key={zone.id}
                      className={`flex items-center justify-between rounded-md border p-3 ${
                        zone.density >= 80
                          ? "border-primary/30 bg-primary/5"
                          : zone.density >= 50
                          ? "border-warning/30 bg-warning/5"
                          : "border-safe/30 bg-safe/5"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`h-3 w-3 rounded-full ${
                            zone.density >= 80 ? "bg-danger animate-pulse" : zone.density >= 50 ? "bg-warning" : "bg-safe"
                          }`}
                        />
                        <span className="font-mono text-sm font-medium text-foreground">{zone.name}</span>
                      </div>
                      <div className="text-right">
                        <span
                          className={`font-mono text-lg font-bold ${
                            zone.density >= 80 ? "text-danger" : zone.density >= 50 ? "text-warning" : "text-safe"
                          }`}
                        >
                          {zone.density}%
                        </span>
                        <p className="font-mono text-xs text-muted-foreground">
                          {zone.density >= 80 ? "ACTION REQUIRED" : zone.density >= 50 ? "MONITOR" : "CLEAR"}
                        </p>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>

          {/* Alert History */}
          <div className="rounded-lg border border-border bg-card p-5">
            <h3 className="mb-4 flex items-center gap-2 font-mono text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              <Bell className="h-4 w-4" />
              Alert History
            </h3>
            {alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground">No alerts dispatched yet.</p>
            ) : (
              <div className="space-y-3">
                {alerts.slice(0, 10).map((alert) => (
                  <div key={alert.id} className="rounded-md border border-border bg-secondary/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-primary" />
                        <span className="font-mono text-xs font-medium text-foreground">
                          ALERT — {alert.zones.length} zone(s)
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span className="font-mono text-xs">
                          {new Date(alert.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">
                      {alert.zones.map((z) => `${z.name}: ${z.density}%`).join(" • ")}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default PolicePortal;

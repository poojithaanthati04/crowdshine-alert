import { useState, useCallback } from "react";
import DashboardHeader from "../components/DashboardHeader";
import CrowdUpload from "../components/CrowdUpload";
import HeatmapVisualization, { type DensityZone } from "../components/HeatmapVisualization";
import AlertToggle from "../components/AlertToggle";
import ZoneStats from "../components/ZoneStats";
import { analyzeCrowdImage } from "../lib/densityAnalysis";
import { toast } from "sonner";

const ALERT_HISTORY_KEY = "crowdguard_alerts";

const Index = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [zones, setZones] = useState<DensityZone[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [alertActive, setAlertActive] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const hasDangerZones = zones.some((z) => z.density >= 80);

  const handleImageUpload = useCallback(async (_file: File, dataUrl: string) => {
    setIsAnalyzing(true);
    setAlertActive(false);
    setImageUrl(null);
    setZones([]);

    try {
      const newZones = await analyzeCrowdImage(dataUrl);
      setImageUrl(dataUrl);
      setZones(newZones);

      const dangerZones = newZones.filter((z) => z.density >= 80);
      if (dangerZones.length > 0) {
        toast.error(`${dangerZones.length} CRITICAL ZONE${dangerZones.length > 1 ? "S" : ""} DETECTED`, {
          description: dangerZones.map((z) => `${z.name}: ${z.density}%`).join(" • "),
          duration: 5000,
        });
      } else {
        toast.success("Analysis complete — all zones within safe capacity");
      }

      // Broadcast to police portal via localStorage event
      const event = {
        type: "density_update",
        timestamp: Date.now(),
        zones: newZones,
      };
      localStorage.setItem("crowdguard_latest", JSON.stringify(event));
      window.dispatchEvent(new StorageEvent("storage", { key: "crowdguard_latest" }));
    } catch (err) {
      console.error("Analysis error:", err);
      toast.error("Analysis failed", {
        description: err instanceof Error ? err.message : "Please try again",
      });
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const handleAlertToggle = useCallback((active: boolean) => {
    if (active) {
      setIsSending(true);
      setTimeout(() => {
        setAlertActive(true);
        setIsSending(false);

        const dangerZones = zones.filter((z) => z.density >= 80);
        toast.success("Police Alert Sent!", {
          description: `SMS dispatched for ${dangerZones.length} critical zone(s)`,
        });

        const alerts = JSON.parse(localStorage.getItem(ALERT_HISTORY_KEY) || "[]");
        alerts.unshift({
          id: Date.now(),
          timestamp: new Date().toISOString(),
          zones: dangerZones,
          status: "active",
        });
        localStorage.setItem(ALERT_HISTORY_KEY, JSON.stringify(alerts.slice(0, 50)));
        window.dispatchEvent(new StorageEvent("storage", { key: ALERT_HISTORY_KEY }));

        const event = {
          type: "police_alert",
          timestamp: Date.now(),
          zones: dangerZones,
        };
        localStorage.setItem("crowdguard_alert", JSON.stringify(event));
        window.dispatchEvent(new StorageEvent("storage", { key: "crowdguard_alert" }));
      }, 1200);
    } else {
      setAlertActive(false);
    }
  }, [zones]);

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <main className="container mx-auto px-4 py-6">
        <div className="mb-6 fade-in-up">
          <h2 className="text-2xl font-bold text-foreground">Control Center</h2>
          <p className="text-sm text-muted-foreground">
            Upload crowd images for instant density analysis and emergency response
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-5 lg:col-span-2">
            <CrowdUpload onImageUpload={handleImageUpload} isAnalyzing={isAnalyzing} />
            <HeatmapVisualization imageUrl={imageUrl} zones={zones} />
          </div>

          <div className="space-y-5">
            <AlertToggle
              isActive={alertActive}
              onToggle={handleAlertToggle}
              hasDangerZones={hasDangerZones}
              isSending={isSending}
            />
            <ZoneStats zones={zones} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;

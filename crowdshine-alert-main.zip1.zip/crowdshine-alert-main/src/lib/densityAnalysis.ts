import { type DensityZone } from "../components/HeatmapVisualization";
import { supabase } from "@/integrations/supabase/client";

export async function analyzeCrowdImage(imageDataUrl: string): Promise<DensityZone[]> {
  // Extract base64 and mime type from data URL
  const mimeType = imageDataUrl.split(";")[0].split(":")[1];
  const imageBase64 = imageDataUrl.split(",")[1];

  const { data, error } = await supabase.functions.invoke("analyze-crowd", {
    body: { imageBase64, mimeType },
  });

  if (error) {
    console.error("AI analysis failed:", error);
    throw new Error(error.message || "Analysis failed");
  }

  if (data?.zones && Array.isArray(data.zones)) {
    return data.zones;
  }

  throw new Error("Invalid response from AI analysis");
}

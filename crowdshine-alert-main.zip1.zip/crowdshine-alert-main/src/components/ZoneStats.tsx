import { type DensityZone } from "./HeatmapVisualization";
import { AlertTriangle, CheckCircle, AlertCircle } from "lucide-react";

interface ZoneStatsProps {
  zones: DensityZone[];
}

const getStatusIcon = (density: number) => {
  if (density >= 80) return <AlertTriangle className="h-4 w-4 text-danger" />;
  if (density >= 50) return <AlertCircle className="h-4 w-4 text-warning" />;
  return <CheckCircle className="h-4 w-4 text-safe" />;
};

const getStatusLabel = (density: number) => {
  if (density >= 80) return "ACTION REQUIRED";
  if (density >= 50) return "MONITOR";
  return "CLEAR";
};

const getBarColor = (density: number) => {
  if (density >= 80) return "bg-danger";
  if (density >= 50) return "bg-warning";
  return "bg-safe";
};

const ZoneStats = ({ zones }: ZoneStatsProps) => {
  if (zones.length === 0) {
    return (
      <div className="rounded-lg border border-border bg-card p-5">
        <h3 className="mb-3 font-mono text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Zone Statistics
        </h3>
        <p className="text-sm text-muted-foreground">No data available. Upload an image to begin analysis.</p>
      </div>
    );
  }

  const avgDensity = Math.round(zones.reduce((sum, z) => sum + z.density, 0) / zones.length);
  const dangerCount = zones.filter((z) => z.density >= 80).length;
  const warningCount = zones.filter((z) => z.density >= 50 && z.density < 80).length;

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <h3 className="mb-4 font-mono text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        Zone Statistics
      </h3>

      {/* Summary bar */}
      <div className="mb-4 grid grid-cols-3 gap-3">
        <div className="rounded-md bg-secondary p-3 text-center">
          <p className="font-mono text-2xl font-bold text-foreground">{avgDensity}%</p>
          <p className="font-mono text-xs text-muted-foreground">AVG DENSITY</p>
        </div>
        <div className={`rounded-md p-3 text-center ${dangerCount > 0 ? "bg-danger/10" : "bg-secondary"}`}>
          <p className={`font-mono text-2xl font-bold ${dangerCount > 0 ? "text-danger" : "text-foreground"}`}>
            {dangerCount}
          </p>
          <p className="font-mono text-xs text-muted-foreground">CRITICAL</p>
        </div>
        <div className={`rounded-md p-3 text-center ${warningCount > 0 ? "bg-warning/10" : "bg-secondary"}`}>
          <p className={`font-mono text-2xl font-bold ${warningCount > 0 ? "text-warning" : "text-foreground"}`}>
            {warningCount}
          </p>
          <p className="font-mono text-xs text-muted-foreground">WARNING</p>
        </div>
      </div>

      {/* Zone list */}
      <div className="space-y-3">
        {zones
          .sort((a, b) => b.density - a.density)
          .map((zone) => (
            <div key={zone.id} className="flex items-center gap-3">
              {getStatusIcon(zone.density)}
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm font-medium text-foreground">{zone.name}</span>
                  <span className={`font-mono text-xs ${
                    zone.density >= 80 ? "text-danger" : zone.density >= 50 ? "text-warning" : "text-safe"
                  }`}>
                    {getStatusLabel(zone.density)}
                  </span>
                </div>
                <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ${getBarColor(zone.density)}`}
                    style={{ width: `${zone.density}%` }}
                  />
                </div>
                <p className="mt-0.5 text-right font-mono text-xs text-muted-foreground">{zone.density}% capacity</p>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default ZoneStats;

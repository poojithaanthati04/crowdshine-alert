import { Shield, ShieldAlert } from "lucide-react";

interface AlertToggleProps {
  isActive: boolean;
  onToggle: (active: boolean) => void;
  hasDangerZones: boolean;
  isSending: boolean;
}

const AlertToggle = ({ isActive, onToggle, hasDangerZones, isSending }: AlertToggleProps) => {
  return (
    <div
      className={`rounded-lg border p-5 transition-all duration-500 ${
        isActive
          ? "border-primary/50 bg-primary/10 glow-danger"
          : "border-border bg-card"
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {isActive ? (
            <ShieldAlert className="h-6 w-6 text-primary pulse-danger" />
          ) : (
            <Shield className="h-6 w-6 text-muted-foreground" />
          )}
          <div>
            <p className="font-semibold text-foreground">Alert Police?</p>
            <p className="text-sm text-muted-foreground">
              {isActive ? "SMS alert sent to officers" : "Toggle to send emergency SMS"}
            </p>
          </div>
        </div>
        <button
          onClick={() => onToggle(!isActive)}
          disabled={!hasDangerZones || isSending}
          className={`relative h-8 w-14 rounded-full transition-all duration-300 ${
            !hasDangerZones
              ? "cursor-not-allowed bg-muted opacity-50"
              : isActive
              ? "bg-primary glow-danger"
              : "bg-secondary hover:bg-muted"
          }`}
        >
          <div
            className={`absolute top-1 h-6 w-6 rounded-full bg-foreground transition-all duration-300 ${
              isActive ? "left-7" : "left-1"
            }`}
          />
        </button>
      </div>
      {isSending && (
        <div className="mt-3 flex items-center gap-2 text-primary">
          <div className="h-3 w-3 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <span className="font-mono text-xs">TRANSMITTING ALERT...</span>
        </div>
      )}
      {isActive && !isSending && (
        <div className="mt-3 flex items-center gap-2 font-mono text-xs text-safe">
          <div className="h-2 w-2 rounded-full bg-safe animate-pulse" />
          ALERT ACTIVE — OFFICERS NOTIFIED
        </div>
      )}
    </div>
  );
};

export default AlertToggle;

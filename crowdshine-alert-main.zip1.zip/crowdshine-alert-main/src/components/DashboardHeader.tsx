import { Shield, Radio, ExternalLink } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const DashboardHeader = () => {
  const location = useLocation();
  const isPolicePortal = location.pathname === "/police";

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Shield className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-foreground">CROWDGUARD</h1>
            <p className="font-mono text-xs text-muted-foreground">REAL-TIME DENSITY MONITORING</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Radio className="h-3 w-3 animate-pulse text-safe" />
            <span className="font-mono text-xs text-safe">SYSTEM ONLINE</span>
          </div>
          {isPolicePortal ? (
            <Link
              to="/"
              className="flex items-center gap-1.5 rounded-md bg-secondary px-3 py-1.5 font-mono text-xs text-secondary-foreground transition-colors hover:bg-muted"
            >
              <ExternalLink className="h-3 w-3" />
              CONTROL CENTER
            </Link>
          ) : (
            <Link
              to="/police"
              className="flex items-center gap-1.5 rounded-md bg-secondary px-3 py-1.5 font-mono text-xs text-secondary-foreground transition-colors hover:bg-muted"
            >
              <ExternalLink className="h-3 w-3" />
              POLICE PORTAL
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;

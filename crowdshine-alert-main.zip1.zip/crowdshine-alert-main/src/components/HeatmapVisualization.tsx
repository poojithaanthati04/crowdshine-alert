import { useEffect, useRef, useState } from "react";

export interface DensityZone {
  id: string;
  name: string;
  x: number; // 0-1 relative
  y: number;
  radius: number; // 0-1 relative
  density: number; // 0-100
}

interface HeatmapVisualizationProps {
  imageUrl: string | null;
  zones: DensityZone[];
}

const getZoneColor = (density: number, alpha: number) => {
  if (density >= 80) return `rgba(220, 38, 38, ${alpha})`; // RED
  if (density >= 50) return `rgba(245, 158, 11, ${alpha})`; // YELLOW/AMBER
  return `rgba(34, 197, 94, ${alpha})`; // GREEN
};

const HeatmapVisualization = ({ imageUrl, zones }: HeatmapVisualizationProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    if (!imageUrl || !canvasRef.current || !containerRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const container = containerRef.current!;
      const containerWidth = container.clientWidth;
      const aspectRatio = img.height / img.width;
      const displayHeight = Math.min(containerWidth * aspectRatio, 500);

      canvas.width = containerWidth;
      canvas.height = displayHeight;
      setDimensions({ width: containerWidth, height: displayHeight });

      // Draw image
      ctx.drawImage(img, 0, 0, containerWidth, displayHeight);

      // Draw heatmap overlay
      zones.forEach((zone) => {
        const cx = zone.x * containerWidth;
        const cy = zone.y * displayHeight;
        const r = zone.radius * Math.min(containerWidth, displayHeight);

        // Radial gradient
        const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
        gradient.addColorStop(0, getZoneColor(zone.density, 0.6));
        gradient.addColorStop(0.6, getZoneColor(zone.density, 0.3));
        gradient.addColorStop(1, getZoneColor(zone.density, 0));

        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Label
        ctx.fillStyle = "white";
        ctx.font = "bold 12px 'JetBrains Mono', monospace";
        ctx.textAlign = "center";
        ctx.shadowColor = "rgba(0,0,0,0.8)";
        ctx.shadowBlur = 4;
        ctx.fillText(zone.name, cx, cy - 8);
        ctx.font = "bold 14px 'JetBrains Mono', monospace";
        ctx.fillText(`${zone.density}%`, cx, cy + 10);
        ctx.shadowBlur = 0;
      });
    };
    img.src = imageUrl;
  }, [imageUrl, zones]);

  if (!imageUrl) {
    return (
      <div className="flex h-64 items-center justify-center rounded-lg border border-border bg-secondary/30">
        <div className="text-center">
          <div className="mx-auto mb-3 h-16 w-16 rounded-full bg-muted flex items-center justify-center">
            <div className="h-8 w-8 rounded-full border-2 border-dashed border-muted-foreground" />
          </div>
          <p className="font-mono text-sm text-muted-foreground">AWAITING IMAGE INPUT</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="relative overflow-hidden rounded-lg border border-border">
      <canvas ref={canvasRef} className="w-full" />
      {/* Legend */}
      <div className="absolute bottom-3 right-3 flex gap-2 rounded-md bg-background/80 px-3 py-2 backdrop-blur-sm">
        <div className="flex items-center gap-1">
          <div className="h-3 w-3 rounded-full bg-danger" />
          <span className="font-mono text-xs text-foreground">&gt;80%</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="h-3 w-3 rounded-full bg-warning" />
          <span className="font-mono text-xs text-foreground">50-80%</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="h-3 w-3 rounded-full bg-safe" />
          <span className="font-mono text-xs text-foreground">&lt;50%</span>
        </div>
      </div>
    </div>
  );
};

export default HeatmapVisualization;

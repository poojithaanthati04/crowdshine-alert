import { useState, useRef, useCallback } from "react";
import { Upload, ImageIcon } from "lucide-react";

interface CrowdUploadProps {
  onImageUpload: (file: File, dataUrl: string) => void;
  isAnalyzing: boolean;
}

const CrowdUpload = ({ onImageUpload, isAnalyzing }: CrowdUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      onImageUpload(file, e.target?.result as string);
    };
    reader.readAsDataURL(file);
  }, [onImageUpload]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onClick={() => fileInputRef.current?.click()}
      className={`relative cursor-pointer rounded-lg border-2 border-dashed p-8 text-center transition-all duration-300 ${
        isDragging
          ? "border-primary bg-primary/5 glow-danger"
          : "border-border hover:border-muted-foreground hover:bg-secondary/50"
      } ${isAnalyzing ? "pointer-events-none opacity-50" : ""}`}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
      />
      <div className="flex flex-col items-center gap-3">
        {isDragging ? (
          <ImageIcon className="h-12 w-12 text-primary animate-pulse" />
        ) : (
          <Upload className="h-12 w-12 text-muted-foreground" />
        )}
        <div>
          <p className="text-lg font-semibold text-foreground">
            {isDragging ? "Drop to Analyze" : "Upload Crowd Image"}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Drag & drop or click to select • JPG, PNG supported
          </p>
        </div>
      </div>
      {isAnalyzing && (
        <div className="absolute inset-0 flex items-center justify-center rounded-lg bg-background/80">
          <div className="flex items-center gap-3">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="font-mono text-sm text-primary">ANALYZING DENSITY...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default CrowdUpload;
